Hello <?php echo e($email_data['name']); ?>

<br><br>
Welcome to my Website!
<br>
Please click the below link to verify your email and activate your account!
<br><br>
<a href="http://localhost/weexpan/public/verify?code=<?php echo e($email_data['email_verification_code']); ?>">Click Here!</a>

<br><br>
Thank you!
<br>
Pratibha rana.com<?php /**PATH E:\xampp\htdocs\weexpan\resources\views/mail/signupmail.blade.php ENDPATH**/ ?>